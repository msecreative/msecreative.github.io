<?php 
/*
Plugin Name: Imgra Helper
Author: MseCreative.
Description: For Wordpress Theme Development.
Author Uri: http://www.msecreative.xyz
Version: 1.0.0

*/
require dirname(__FILE__).'/shortcode/section_title.php';
require dirname(__FILE__).'/shortcode/color_section_title.php';
require dirname(__FILE__).'/shortcode/counter_box.php';
require dirname(__FILE__).'/shortcode/imgra_pricing.php';
require dirname(__FILE__).'/shortcode/about_us.php';
require dirname(__FILE__).'/shortcode/imgra_slider.php';
require dirname(__FILE__).'/shortcode/imgra_testimonial.php';
require dirname(__FILE__).'/shortcode/imgra_skill_section.php';
require dirname(__FILE__).'/shortcode/imgra_service.php';
require dirname(__FILE__).'/shortcode/imgra_consultent.php';
require dirname(__FILE__).'/shortcode/imgra_experience.php';
require dirname(__FILE__).'/shortcode/service_title_section.php';
require dirname(__FILE__).'/shortcode/client_logo.php';
require dirname(__FILE__).'/shortcode/accordion.php';
require dirname(__FILE__).'/shortcode/call_to_action.php';
require dirname(__FILE__).'/shortcode/about_tab.php';
require dirname(__FILE__).'/shortcode/contact_us.php';

 ?>