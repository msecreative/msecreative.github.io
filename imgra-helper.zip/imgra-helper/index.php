<?php 
	//Silence is golden
 ?>