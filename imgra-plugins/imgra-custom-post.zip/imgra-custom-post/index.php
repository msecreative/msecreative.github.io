<?php 

//Siclence is Golden


 ?>